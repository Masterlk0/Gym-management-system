<?php
include 'dbh.php'; // Include your database connection file
session_start(); // Start the session

// Initialize error message
$error = '';

// Handle the login form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SQL statement to fetch user details
    $stmt = $conn->prepare("SELECT id, password FROM customers WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // User exists, fetch the hashed password
        $stmt->bind_result($userId, $hashed_password);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashed_password)) {
            // Password is correct, set session variables
            $_SESSION['user_id'] = $userId;
            $_SESSION['email'] = $email;

            // Redirect to gym management page
            header("Location: ../user/gymManagement.php");
            exit(); // Ensure no further code is executed
        } else {
            $error = 'Invalid password. Please try again.';
        }
    } else {
        $error = 'No account found with that email. Please register.';
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Login - Gym Website</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f7f7f7; /* Light background for better contrast */
        }
        .login-container {
            max-width: 400px; /* Set a max width for the form */
            margin: auto;
            padding: 2rem;
            background-color: #fff; /* White background for the form */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }
    </style>
</head>
<body>
    <div class="login-container mt-5">
        <h2 class="text-center">Customer Login</h2>

        <?php if ($error): ?>
            <div class="alert alert-danger fade show" role="alert">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST"> <!-- Action updated to submit to the same page -->
            <div class="mb-3">
                <label for="email" class="form-label">Email address</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100">Login</button>
            <div class="mt-3 text-center">
                <a href="registerCustomer.php">Don't have an account? Register here.</a>
            </div>
            <div class="mt-3 text-center">

        <a href="./home.php">Back to Home</a>
    </div>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
