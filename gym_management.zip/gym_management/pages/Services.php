<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services - Gym Website</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="./home.php">Apex Fitness</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Services Section -->
    <section class="py-5">
        <div class="container">
            <h1 class="text-center">Our Services</h1>
            <p class="lead text-center">Explore the wide range of services we offer to help you achieve your fitness goals.</p>

            <div class="row">
                <div class="col-md-4">
                    <div class="card mb-4">
                        <img src="../images/personal-trainer.jpg" class="card-img-top" alt="Personal Training">
                        <div class="card-body">
                            <h5 class="card-title">Personal Training</h5>
                            <p class="card-text">Get customized workout plans and one-on-one coaching from our certified trainers.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <img src="../images/istockphoto-1207041834-612x612.jpg" class="card-img-top" alt="Group Classes">
                        <div class="card-body">
                            <h5 class="card-title">Group Classes</h5>
                            <p class="card-text">Join our exciting group classes including Yoga, Zumba, and HIIT.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <img src="../images/images.jpg" class="card-img-top" alt="Nutrition Guidance">
                        <div class="card-body">
                            <h5 class="card-title">Nutrition Guidance</h5>
                            <p class="card-text">Get advice from our nutrition experts to complement your fitness journey.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-4">
        <div class="container">
            <p>&copy; 2024 Apex Fitness. All Rights Reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
