<!DOCTYPE html>
<html lang="en">    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym Website</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .custom-bg {
            background-color: #f0f0f0; /* Light gray */
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="./home.php">Apex Fitness</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../pages/home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Contact.php">Contact</a>
                    </li>
                </ul>
                <!-- Admin Button -->
                <a href="./admin_login.php" class="btn btn-warning ms-3">Admin</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <section class="hero bg-secondary text-center py-5">
    <div class="container">
        <h1>Welcome to Our Gym</h1>
        <p>Join us to achieve your fitness goals.</p>
        <a href="./user_login.php" class="btn btn-primary btn-lg">Get Started</a> <!-- Updated link -->
    </div>
</section>

    <!-- Services Section -->
<section class="py-5">
    <div class="container">
        <h2 class="text-center">NEVER GIVE UP</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="../images/1234.png" class="card-img-top" alt="Cardio Training"> <!-- Update image -->
                    <div class="card-body">
                        <h5 class="card-title">Cardio Training</h5>
                        <p class="card-text">Improve your stamina with our state-of-the-art cardio equipment like treadmills, ellipticals, and bikes.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="../images/2.jpg" class="card-img-top" alt="Strength Training"> <!-- Update image -->
                    <div class="card-body">
                        <h5 class="card-title">Strength Training</h5>
                        <p class="card-text">Build muscle and tone your body with a variety of weight machines, free weights, and resistance training equipment.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="../images/personal-trainer.jpg" class="card-img-top" alt="Yoga Classes"> <!-- Update image -->
                    <div class="card-body">
                        <h5 class="card-title">Yoga and Flexibility</h5>
                        <p class="card-text">Enhance flexibility and find your inner peace with our guided yoga and stretching classes.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-4">
        <div class="container">
            <p>&copy; 2024 Apex Fitness. All Rights Reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
