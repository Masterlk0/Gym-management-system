<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Apex Fitness</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body {
            height: 100%;
        }
        .content-wrapper {
            min-height: 100%;
            display: flex;
            flex-direction: column;
        }
        .content {
            flex: 1;
        }
        footer {
            background-color: #343a40;
            color: white;
            padding: 1rem 0;
            text-align: center;
        }
        /* Updated Hero Section */
        .hero-section {
            background: url('https://via.placeholder.com/1200x400/000000/ffffff?text=Welcome+to+Apex+Fitness') center/cover no-repeat;
            padding: 100px 0;
            color: #f8f9fa;
            text-align: center;
            background-color: #000000; /* Fall-back color */
        }
        .hero-section h1 {
            font-size: 3.5rem;
            font-weight: bold;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.7);
        }
        .hero-section p {
            color: #f1c40f; /* Accent color for tagline */
        }
        .lead {
            font-size: 1.25rem;
            margin-bottom: 2rem;
        }
        .about-image {
            max-width: 100%;
            border-radius: 10px;
        }
        .testimonial-card {
            border: none;
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
    <div class="content-wrapper">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="./home.php">Apex Fitness</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="home.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="about.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="services.php">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Hero Section -->
        <section class="hero-section">
            <div class="container">
                
                <p class="lead"></p>
            </div>
        </section>

        <!-- About Us Section -->
        <section class="content py-5">
            <div class="container">
                <div class="row align-items-center mb-5">
                    <div class="col-md-6">
                        <h2>Our Story</h2>
                        <p>We are a team of fitness enthusiasts committed to helping you reach your fitness goals. Apex Fitness has been serving the community for over 10 years, offering state-of-the-art equipment and expert trainers.</p>
                        <p>Our mission is to empower people to live healthier lives through fitness and wellness. Whether you're starting your fitness journey or are a seasoned athlete, we have the right programs and support to help you succeed.</p>
                    </div>
                    <div class="col-md-6">
                        <!-- Add actual image for gym equipment -->
                        <img src="../images/4.jpg" alt="Gym Equipment" class="about-image">
                    </div>
                </div>

                <!-- Community Section -->
                <div class="row align-items-center mb-5">
                    <div class="col-md-6 order-md-2">
                        <h2>Our Community</h2>
                        <p>At Apex Fitness, we value community, dedication, and personal growth. Our members are more than just clients – they are family. We foster an inclusive environment where everyone can thrive, no matter their fitness level.</p>
                        <p>Join us today and become part of our fitness family!</p>
                    </div>
                    <div class="col-md-6 order-md-1">
                        <!-- Add actual image for group fitness class -->
                        <img src="../images/cardback.jpg" alt="Group Fitness Class" class="about-image">
                    </div>
                </div>

                <!-- Testimonials -->
                <h3 class="text-center mb-4">What Our Members Say</h3>
                <div class="row text-center">
                    <div class="col-md-4">
                        <div class="card testimonial-card">
                            <div class="card-body">
                                <blockquote class="blockquote mb-0">
                                    <p>"Apex Fitness changed my life! The trainers are amazing and the community is so supportive!"</p>
                                    <footer class="blockquote-footer">John Doe</footer>
                                </blockquote>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card testimonial-card">
                            <div class="card-body">
                                <blockquote class="blockquote mb-0">
                                    <p>"The facilities are top-notch and I love the variety of classes offered."</p>
                                    <footer class="blockquote-footer">Jane Smith</footer>
                                </blockquote>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card testimonial-card">
                            <div class="card-body">
                                <blockquote class="blockquote mb-0">
                                    <p>"I’ve never felt more motivated and energized. Best gym ever!"</p>
                                    <footer class="blockquote-footer">Alex Johnson</footer>
                                </blockquote>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer -->
        <footer>
            <div class="container">
                <p>&copy; 2024 Apex Fitness. All Rights Reserved.</p>
            </div>
        </footer>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
