<?php
include("dbh.php");

if (isset($_GET['id'])) {
    $member_id = $_GET['id'];
    
    // First, delete the member's enrollments
    $deleteEnrollmentsQuery = "DELETE FROM class_enrollments WHERE member_id = $member_id";
    if (mysqli_query($conn, $deleteEnrollmentsQuery)) {
        // Now, delete the member
        $deleteMemberQuery = "DELETE FROM members WHERE id = $member_id";
        if (mysqli_query($conn, $deleteMemberQuery)) {
            header("Location: member_details.php");
            exit();
        } else {
            echo "Error deleting member record: " . mysqli_error($conn);
        }
    } else {
        echo "Error deleting enrollments: " . mysqli_error($conn);
    }
} else {
    header("Location: member_details.php");
    exit();
}
?>
