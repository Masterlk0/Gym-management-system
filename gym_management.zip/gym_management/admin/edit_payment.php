<?php
include("dbh.php"); // Include DB connection

if (isset($_GET['id'])) {
    $payment_id = $_GET['id'];

    // Fetch payment details
    $query = "SELECT * FROM payment WHERE payment_id = $payment_id";
    $result = mysqli_query($conn, $query);
    $payment = mysqli_fetch_assoc($result);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Update payment details
        $amount = $_POST['Amount'];
        $payment_type = $_POST['payment_type'];
        $customer_id = $_POST['customer_id'];
        $customer_name = $_POST['customer_name'];

        $update_query = "UPDATE payment SET Amount='$amount', payment_type='$payment_type', customer_id='$customer_id', customer_name='$customer_name' WHERE payment_id = $payment_id";
        if (mysqli_query($conn, $update_query)) {
            echo "Payment updated successfully!";
            header("Location: payment.php");
            exit();
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    }
} else {
    header("Location: payment.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Payment</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h3>Edit Payment</h3>
    <form method="POST">
        <div class="form-group">
            <label for="amount">Amount</label>
            <input type="text" class="form-control" id="Amount" name="Amount" value="<?php echo isset($payment['Amount']) ? $payment['Amount'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="payment_type">Payment Type</label>
            <input type="text" class="form-control" id="payment_type" name="payment_type" value="<?php echo isset($payment['payment_type']) ? $payment['payment_type'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="customer_id">Customer ID</label>
            <input type="text" class="form-control" id="customer_id" name="customer_id" value="<?php echo isset($payment['customer_id']) ? $payment['customer_id'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="customer_name">Customer Name</label>
            <input type="text" class="form-control" id="customer_name" name="customer_name" value="<?php echo isset($payment['customer_name']) ? $payment['customer_name'] : ''; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
</body>
</html>
