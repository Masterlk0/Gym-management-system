<!DOCTYPE html>
<?php
include 'dbh.php';

$query = "SELECT * FROM `Trainer`";
$result1 = mysqli_query($conn, $query);
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member and Trainer Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .jumbotron {
            border-radius: 0;
            background: url('../images/3.jpg') no-repeat;
            background-size: cover;
            height: 400px;
        }
        .panel {
            background-color: #3C3D37;
            color: #ffffff;
            padding: 15px;
            border-radius: 4px;
        }
        .panel-title {
            margin-bottom: 15px;
            font-size: 18px;
            color: #ffffff;
        }
        .list-group-item.active {
            background-color: #3C3D37;
            border-color: black;
        }
        .form-control {
            margin-bottom: 15px;
        }
        .btn-primary {
            width: 100%;
        }
        header nav {
            background-color: #3C3D37;
            padding: 10px;
        }
    </style>
</head>
<body>

    <div class="jumbotron"></div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
                <!-- Members Panel -->
                <div class="panel">
                    <h4 class="panel-title text-center">Members</h4>
                    <div class="list-group">
                        <a href="" class="list-group-item active">Register Members</a>
                        <a href="member_details.php" class="list-group-item" style="color: #3C3D37;">Member Details</a>
                        <a href="package.php" class="list-group-item" style="color: #3C3D37;">Package Details</a>
                        <a href="payment.php" class="list-group-item" style="color: #3C3D37;">Payments</a>
                    </div>
                </div>
                <hr>
                <!-- Trainers Panel -->
                <div class="panel">
                    <h4 class="panel-title text-center">Trainers</h4>
                    <div class="list-group">
                        <a href="trainer.php" class="list-group-item active" style="color: #3C3D37;">Trainer List</a>
                        <a href="trainer.php" class="list-group-item" style="color: #3C3D37;">Trainer Details</a>
                        <a href="add_trainer.php" class="list-group-item" style="color: #3C3D37;">Add New Trainer</a>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <!-- Register New Members Card -->
                <div class="card">
                    <div class="card-body" style="background-color:#3C3D37;color: #FFFFFF;">
                        <h3>Register New Members</h3>
                    </div> 
                    <div class="card-body">
                    <form class="form-group" action="func.php" method="post">
                        <label>First Name:</label>
                        <input type="text" name="fname" class="form-control" required>
                        <label>Last Name:</label>
                        <input type="text" name="lname" class="form-control" required>
                        <label>Email:</label>
                        <input type="email" name="email" class="form-control" required>
                        <label>Member ID:</label>
                        <input type="text" name="contact" class="form-control" required>        
                        <label>Trainer:</label> 
                        <select class="form-control" name="trainer_id" required>
                            <option value="">Select Trainer</option>
                            <?php while($row1 = mysqli_fetch_array($result1)): ?>
                                <option value="<?php echo $row1['Trainer_id']; ?>"><?php echo $row1['Name']; ?></option>
                            <?php endwhile; ?>
                        </select>
                        <input type="submit" class="btn btn-primary" name="pat_submit" value="Register">                  
                    </form>
                    </div>
                </div>
            </div>
            <div class="col-md-1"></div>
        </div>
    </div>

    <!-- Header for Logout -->
    <header>
        <nav>
            <div class="main-wrapper">
                <div class="nav-logout">
                    <?php
                    if (isset($_SESSION['u_id'])) {
                        echo '<form action="../pages/home.php" method="POST" style="display: inline;">
                                <button type="submit" name="submit" class="btn btn-light">Logout</button>
                              </form>';	
                    } else {
                        echo '<a href="../pages/home.php" class="btn btn-danger" style="background-color:red;color:white">Logout</a>';
                    }
                    ?>
                </div>
            </div>
        </nav>
    </header>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>

</body>
</html>
