<?php
include 'dbh.php';

if (isset($_GET['id'])) {
    $trainer_id = $_GET['id'];
    $query = "SELECT * FROM trainer WHERE trainer_id = $trainer_id";
    $result = mysqli_query($conn, $query);
    $trainer = mysqli_fetch_assoc($result);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = $_POST['name'];
        $phone = $_POST['phone'];

        $update_query = "UPDATE trainer SET name='$name', phone='$phone' WHERE Trainer_id = $trainer_id";
        if (mysqli_query($conn, $update_query)) {
            header('Location: trainer.php'); // Redirect back to the trainer list page
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    }
} else {
    header('Location: trainer.php'); // Redirect if no ID is set
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Trainer</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h3>Edit Trainer</h3>
    <form method="POST">
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo $trainer['Name']; ?>" required>
        </div>
        <div class="form-group">
            <label for="phone">Phone</label>
            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo $trainer['Phone']; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
</body>
</html>
