<?php
include("dbh.php"); // Include DB connection

if (isset($_GET['id'])) {
    $package_id = $_GET['id'];
    
    // Fetch package details
    $query = "SELECT * FROM package WHERE package_id = $package_id";


    $result = mysqli_query($conn, $query);
    $package = mysqli_fetch_assoc($result);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Update member details
        $package_name = $_POST['package_name'];
        $amount = $_POST['amount'];

        $update_query = "UPDATE package SET Package_name='$package_name', Amount='$amount' WHERE package_id = $package_id";
        if (mysqli_query($conn, $update_query)) {
            echo "package updated successfully!";
            header("Location: package.php");
            exit();
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    }
} else {
    header("Location: member_details.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Package</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h3>Edit Package</h3>
    <form method="POST">
    <div class="form-group">
            <label for="package_name">Package Name</label>
            <input type="text" class="form-control" id="package_name" name="package_name" value="<?php echo $package['Package_name']; ?>" required>
        </div>
        <div class="form-group">
            <label for="amount">Amount</label>
            <input type="text" class="form-control" id="amount" name="amount" value="<?php echo $package['Amount']; ?>" required>
        </div>

        
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
</body>
</html>
