<?php
include("dbh.php");

if (isset($_GET['id'])) {
    $package_id = $_GET['id'];
    
    // Delete the package
    $query = "DELETE FROM package WHERE package_id = $package_id";
    if (mysqli_query($conn, $query)) {
        header("Location: package.php");
        exit();
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    header("Location: package.php");
    exit();
}
?>
