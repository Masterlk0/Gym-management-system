<!DOCTYPE html>
<?php include 'dbh.php'; include 'func.php'; ?>
<html>
<head>
    <title>Add New Trainer</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <style>
        body {
            background: url('./images/personal-trainer.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5); /* Black with 50% opacity */
            z-index: 1;
        }
        .container {
            position: relative;
            z-index: 2; /* Ensure content is above the overlay */
        }
        .card-body {
            background-color: #424242;
            color: #ffffff;
        }
    </style>
</head>
<body>
    <div class="overlay"></div>

    <div class="container mt-5">
        <div class="card">
            <div class="card-body">
                <!-- Go Back Button -->
                <a href="admin-panel.php" class="btn btn-secondary mb-3">Go Back</a>

                <h3>Register New Trainer</h3>
                <form class="form-group" action="func.php" method="post">
                    <label>Trainer ID</label>
                    <input type="text" name="Trainer_id" class="form-control" required><br>
                    <label>Name</label>
                    <input type="text" name="Name" class="form-control" required><br>
                    <label>Phone</label>
                    <input type="text" name="phone" class="form-control" required><br> 
                    <input type="submit" class="btn btn-primary" name="tra_submit" value="Register">
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
</body>
</html>
