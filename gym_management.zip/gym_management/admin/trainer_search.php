<html>
<head>
    <title>Patient Details</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
</head>
<body>
    <?php
    include("func.php");
    include 'dbh.php';
    
    if (isset($_POST['patient_search_submit'])) {
        // Get the ID from the form
        $member_id = mysqli_real_escape_string($conn, $_POST['search']); // Assuming 'search' is the input name

        // Query to search for the member by ID
        $query = "SELECT * FROM members WHERE id='$member_id'"; // Replace 'id' with the actual column name for member ID
        $result = mysqli_query($conn, $query);

        // Display results
        echo "<div class='container-fluid' style='margin-top:50px;'>
                <div class='card'>
                    <div class='card-body'>
                        <a href='member_details.php' class='btn btn-light'>Go Back</a>
                    </div>
                    <img src='../images/1.jpg'>
                    <table class='table table-hover'>
                        <thead>
                            <tr>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email ID</th>
                                <th>Contact</th>
                                <th>Trainer ID</th>
                            </tr>   
                        </thead>
                        <tbody>";

        // Fetch and display member details
        while ($row = mysqli_fetch_array($result)) {
            $fname = $row['first_name'];
            $lname = $row['last_name'];
            $email = $row['email'];
            $contact = $row['contact'];
            $trainer_id = $row['trainer_id'];
            echo "<tr>
                    <td>$fname</td>
                    <td>$lname</td>
                    <td>$email</td>
                    <td>$contact</td>
                    <td>$trainer_id</td>
                  </tr>";
        }
        echo "</tbody></table></div></div></div>";
    }
    ?>
    

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
</body>
</html>
