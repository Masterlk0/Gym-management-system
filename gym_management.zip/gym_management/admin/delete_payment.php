<?php
include("dbh.php"); // Include DB connection

if (isset($_GET['id'])) {
    $payment_id = $_GET['id'];

    // Delete payment
    $query = "DELETE FROM payment WHERE payment_id = $payment_id";
    if (mysqli_query($conn, $query)) {
        header("Location: payment.php");
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    header("Location: payment.php");
}
?>
