<?php
include("dbh.php"); // Include DB connection
if (isset($_GET['id'])) {
    $member_id = $_GET['id'];
    
    // Fetch member details
    $query = "SELECT * FROM members WHERE id = $member_id";
    $result = mysqli_query($conn, $query);
    $member = mysqli_fetch_assoc($result);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Update member details
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];
        $trainer_id = $_POST['trainer_id'];

        $update_query = "UPDATE members SET first_name='$first_name', last_name='$last_name', email='$email', contact='$contact', trainer_id='$trainer_id' WHERE id = $member_id";
        if (mysqli_query($conn, $update_query)) {
            echo "Member updated successfully!";
            header("Location: member_details.php");
            exit();
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    }
} else {
    header("Location: member_details.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Member</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h3>Edit Member</h3>
    <form method="POST">
        <div class="form-group">
            <label for="first_name">First Name</label>
            <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $member['first_name']; ?>" required>
        </div>
        <div class="form-group">
            <label for="last_name">Last Name</label>
            <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $member['last_name']; ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo $member['email']; ?>" required>
        </div>
        <div class="form-group">
            <label for="contact">Contact</label>
            <input type="text" class="form-control" id="contact" name="contact" value="<?php echo $member['contact']; ?>" required>
        </div>
        <div class="form-group">
            <label for="trainer_id">Trainer ID</label>
            <input type="text" class="form-control" id="trainer_id" name="trainer_id" value="<?php echo $member['trainer_id']; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
</body>
</html>
