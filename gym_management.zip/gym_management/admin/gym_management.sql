

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";




CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `class_name` varchar(100) NOT NULL,
  `instructor_name` varchar(100) NOT NULL,
  `schedule` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `classes` (`id`, `class_name`, `instructor_name`, `schedule`, `description`) VALUES
(1, 'Yoga Basics', 'Alice Smith', 'Mon & Wed 8 AM', 'An introduction to yoga.'),
(2, 'Advanced HIIT', 'Bob Johnson', 'Tue & Thu 6 PM', 'High-intensity interval training for advanced members.'),
(3, 'Pilates', 'Carol Williams', 'Fri 5 PM', 'Improve your flexibility and core strength.');



CREATE TABLE `class_enrollments` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `enrollment_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `class_enrollments` (`id`, `class_id`, `member_id`, `enrollment_date`) VALUES
(8, 1, 1, '2024-09-30 08:06:30'),
(9, 2, 1, '2024-09-30 08:06:32'),
(13, 3, 1, '2024-09-30 08:28:07'),
(14, 1, 8, '2024-09-30 13:52:41'),
(15, 2, 8, '2024-09-30 13:52:42'),
(16, 3, 8, '2024-09-30 13:52:42');



CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `weight` decimal(5,2) NOT NULL,
  `height` decimal(5,2) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `customers` (`id`, `name`, `address`, `age`, `contact_number`, `weight`, `height`, `email`, `password`, `created_at`) VALUES
(1, 'user', 'colombo', 24, '0123456789', 75.00, 175.00, 'user@gmail.com', '$2y$10$JV2ApND7puVJzkotLf9Lnu8ffJaNhgw3/8SmfK0ju9M2JMRKWvWSO', '2024-09-29 13:04:41'),
(7, 'sunil', 'colombo', 23, '0873663563', 23.00, 175.00, 'sunil@gmail.com', '$2y$10$5yGPJVrg72g2Lb24ULz27.0XWCaaSqaynZPnLW2.HNPccK5Z74Ek2', '2024-09-30 13:47:06'),
(8, 'ushan', 'welikanna', 34, '4454454545', 45.00, 176.00, 'ushan@gmail.com', '$2y$10$0eDwOzila17esYrXznStseWAPe9uQF8Caot.c7y85XcLPuJC/QTZC', '2024-09-30 13:52:21');


CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `trainer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `members` (`id`, `first_name`, `last_name`, `email`, `contact`, `trainer_id`) VALUES
(15, 'samson', 'silva', 'samson@gmail.com', '1', 1);



CREATE TABLE `package` (
  `Package_id` varchar(40) NOT NULL,
  `Package_name` varchar(40) NOT NULL,
  `Amount` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `package` (`Package_id`, `Package_name`, `Amount`) VALUES
('1', 'weight loss', 10000);



CREATE TABLE `payment` (
  `Payment_id` int(10) NOT NULL,
  `Amount` int(20) NOT NULL,
  `customer_id` varchar(20) NOT NULL,
  `payment_type` varchar(20) NOT NULL,
  `customer_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `payment` (`Payment_id`, `Amount`, `customer_id`, `payment_type`, `customer_name`) VALUES
(1, 5000, '1', 'cash', 'kamal');



CREATE TABLE `trainer` (
  `Trainer_id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Phone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `trainer` (`Trainer_id`, `Name`, `Phone`) VALUES
(1, 'john', '0123456789');



CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `transaction_type` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `transactions` (`id`, `member_id`, `amount`, `transaction_date`, `transaction_type`, `status`) VALUES
(7, 8, 15000.00, '2024-09-30 14:37:32', 'membership', 'completed');



CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `users` (`id`, `username`, `password`) VALUES
(3, 'admin', '$2y$10$I2aPVt8IxzuNrzjMz2WVu..B4kernK2E7EiFZfvjiie052rOrvEEW');


ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `class_enrollments`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);


ALTER TABLE `members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `trainer_id` (`trainer_id`);


ALTER TABLE `trainer`
  ADD PRIMARY KEY (`Trainer_id`);


ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);




ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;


ALTER TABLE `class_enrollments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;



ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;


ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;


ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;


ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;




ALTER TABLE `members`
  ADD CONSTRAINT `members_ibfk_1` FOREIGN KEY (`trainer_id`) REFERENCES `trainer` (`Trainer_id`) ON DELETE SET NULL;
COMMIT;


