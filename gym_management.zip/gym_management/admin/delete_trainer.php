<?php
include 'dbh.php';

if (isset($_GET['id'])) {
    $trainer_id = $_GET['id'];
    $query = "DELETE FROM trainer WHERE Trainer_id = $trainer_id";

    if (mysqli_query($conn, $query)) {
        header('Location: trainer.php'); // Redirect back to the trainer list page
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    header('Location: trainer.php'); // Redirect if no ID is set
}
?>
