<!DOCTYPE html>
<?php include 'dbh.php'; include 'func.php'; ?>
<html>
<head>
    <title>Trainer Details</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <style>
        body {
            background: url('./images/personal-trainer.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1;
        }
        .container {
            position: relative;
            z-index: 2;
        }
        .card-body {
            background-color: #3C3D37;
            color: black;
        }
        .table {
            background-color: #fff;
            border-radius: 5px;
            overflow: hidden;
        }
        th, td {
            vertical-align: middle;
        }
        thead {
            background-color: #3C3D37;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <div class="overlay"></div>

    <div class="container mt-5">
        <div class="card">
            <div class="card-body">
                <!-- Go Back Button -->
                <a href="admin-panel.php" class="btn btn-primary mb-4">Go Back</a>

                <h3 class="text-center mb-4">Trainer Information</h3>
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>Trainer ID</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Actions</th> <!-- Column for Edit/Delete buttons -->
                        </tr>   
                    </thead>
                    <tbody>
                        <?php get_trainer_with_actions(); ?> <!-- Modified function to include buttons -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
</body>
</html>
