<?php

include 'dbh.php'; // Database connection file

if (isset($_POST['login_submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare statement for login
    $stmt = $conn->prepare("SELECT * FROM logintb WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        header("Location: admin-panel.php");
        exit();
    } else {
        echo "<script>alert('Error: Invalid login credentials.')</script>";
        echo "<script>window.open('admin-panel.php', '_self')</script>";
    }
}

if (isset($_POST['pat_submit'])) {
    // Get the form data
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $trainer_id = $_POST['trainer_id'];

    // Prepare statement for adding a member
    $stmt = $conn->prepare("INSERT INTO members (first_name, last_name, email, contact, trainer_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssi", $fname, $lname, $email, $contact, $trainer_id); // 's' for string, 'i' for integer

    if ($stmt->execute()) {
        echo "<script>alert('New member registered successfully!')</script>";
        echo "<script>window.open('admin-panel.php', '_self')</script>"; // Redirect on success
    } else {
        echo "<script>alert('Error registering member: " . $stmt->error . "')</script>";
    }

    // Close the statement
    $stmt->close();
}


if (isset($_POST['tra_submit'])) {
    $Trainer_id = $_POST['Trainer_id'];
    $Name = $_POST['Name'];
    $phone = $_POST['phone'];

    // Prepare statement for adding a trainer
    $stmt = $conn->prepare("INSERT INTO Trainer (Trainer_id, Name, phone) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $Trainer_id, $Name, $phone);

    if ($stmt->execute()) {
        echo "<script>alert('Trainer added successfully.')</script>";
        echo "<script>window.open('admin-panel.php', '_self')</script>";
    } else {
        echo "<script>alert('Error adding trainer: " . $stmt->error . "')</script>";
    }
}

if (isset($_POST['pay_submit'])) {
    $Payment_id = $_POST['Payment_id'];
    $Amount = $_POST['Amount'];
    $customer_id = $_POST['customer_id'];
    $payment_type = $_POST['payment_type'];
    $customer_name = $_POST['customer_name'];

    // Prepare statement for adding a payment
    $stmt = $conn->prepare("INSERT INTO Payment (Payment_id, Amount, customer_id, payment_type, customer_name) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $Payment_id, $Amount, $customer_id, $payment_type, $customer_name);

    if ($stmt->execute()) {
        echo "<script>alert('Payment successful.')</script>";
        echo "<script>window.open('admin-panel.php', '_self')</script>";
    } else {
        echo "<script>alert('Error processing payment: " . $stmt->error . "')</script>";
    }
}

// Function to fetch package details
function get_package() {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM Package");
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['Package_id']}</td>
                <td>{$row['Package_name']}</td>
                <td>{$row['Amount']}</td>
              </tr>";
    }
}

// Function to fetch trainer details
function get_trainer() {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM Trainer");
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['Trainer_id']}</td>
                <td>{$row['Name']}</td>
                <td>{$row['Phone']}</td>
              </tr>";
    }
}



function get_member_details_with_actions() {
    global $conn; // Assuming you have a database connection stored in $conn

    $query = "SELECT * FROM members"; // Adjust the table name as per your DB
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        $member_id = $row['id'];
        $first_name = $row['first_name'];
        $last_name = $row['last_name'];
        $email = $row['email'];
        $contact = $row['contact'];
        $trainer_id = $row['trainer_id'];

        echo "<tr>
                <td>$member_id</td>
                <td>$first_name</td>
                <td>$last_name</td>
                <td>$email</td>
                <td>$contact</td>
                <td>$trainer_id</td>
                <td>
                    <a href='edit_member.php?id=$member_id' class='btn btn-warning btn-sm'>Edit</a>
                    <a href='delete_member.php?id=$member_id' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this member?\");'>Delete</a>
                </td>
              </tr>";
    }
}


function get_package_with_actions() {
    global $conn; // Assuming you have a database connection stored in $conn

    $query = "SELECT * FROM package"; // Adjust the table name as per your DB
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        $package_id = $row['Package_id'];
        $package_name = $row['Package_name'];
        $amount = $row['Amount'];

        echo "<tr>
                <td>$package_id</td>
                <td>$package_name</td>
                <td>$amount</td>
                <td>
                    <a href='edit_package.php?id=$package_id' class='btn btn-warning btn-sm'>Edit</a>
                    <a href='delete_package.php?id=$package_id' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this package?\");'>Delete</a>
                </td>
              </tr>";
    }
}

function get_payment() {
    global $conn; // Assumes a global DB connection
    $query = "SELECT * FROM payment"; // Adjust the query to match your table structure
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        $payment_id = $row['Payment_id'];
        $amount = $row['Amount'];
        $payment_type = $row['payment_type'];
        $customer_id = $row['customer_id'];
        $customer_name = $row['customer_name'];

        echo "<tr>
                <td>$payment_id</td>
                <td>$amount</td>
                <td>$payment_type</td>
                <td>$customer_id</td>
                <td>$customer_name</td>
                <td>
                    <a href='edit_payment.php?id=$payment_id' class='btn btn-warning'>Edit</a>
                    <a href='delete_payment.php?id=$payment_id' class='btn btn-danger' onclick='return confirm(\"Are you sure you want to delete this payment?\")'>Delete</a>
                </td>
              </tr>";
    }
}


if (isset($_POST['save_package'])) {
    $package_id = $_POST['package_id'];
    $package_name = $_POST['package_name'];
    $amount = $_POST['amount'];

    $query = "INSERT INTO package (Package_id, Package_name, Amount) VALUES ('$package_id', '$package_name', '$amount')";
    
    if (mysqli_query($conn, $query)) {
        echo "Package added successfully!";
        header("Location: package.php"); // Redirect to package details page
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}


function get_trainer_with_actions() {
    global $conn; // Make sure the connection is accessible
    $query = "SELECT * FROM trainer"; // Modify the table name as per your database schema
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['Trainer_id']}</td>
                <td>{$row['Name']}</td>
                <td>{$row['Phone']}</td>
                <td>
                    <a href='edit_trainer.php?id={$row['Trainer_id']}' class='btn btn-warning'>Edit</a>
                    <a href='delete_trainer.php?id={$row['Trainer_id']}' class='btn btn-danger' onclick='return confirm(\"Are you sure you want to delete this trainer?\");'>Delete</a>
                </td>
              </tr>";
    }
}


?>
