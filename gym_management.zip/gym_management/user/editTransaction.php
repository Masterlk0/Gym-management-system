<?php
include 'dbh.php';
session_start();

// Ensure the transaction ID is provided
if (!isset($_POST['transaction_id'])) {
    header("Location: gymManagement.php");
    exit();
}

$transactionId = $_POST['transaction_id'];

// Fetch the current transaction details
$query = "SELECT * FROM transactions WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $transactionId);
$stmt->execute();
$result = $stmt->get_result();
$transaction = $result->fetch_assoc();

if (!$transaction) {
    echo "Transaction not found!";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Transaction</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h3>Edit Transaction</h3>
    <form action="updateTransaction.php" method="POST">
        <input type="hidden" name="transaction_id" value="<?php echo $transaction['id']; ?>">

        <!-- Amount -->
        <div class="mb-3">
            <label for="amount" class="form-label">Amount</label>
            <input type="number" step="0.01" name="amount" id="amount" class="form-control" value="<?php echo $transaction['amount']; ?>" required>
        </div>

        <!-- Status -->
        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select name="status" id="status" class="form-control">
                <option value="completed" <?php if ($transaction['status'] == 'completed') echo 'selected'; ?>>Completed</option>
                <option value="pending" <?php if ($transaction['status'] == 'pending') echo 'selected'; ?>>Pending</option>
                <option value="failed" <?php if ($transaction['status'] == 'failed') echo 'selected'; ?>>Failed</option>
            </select>
        </div>

        <!-- Transaction Date -->
        <div class="mb-3">
            <label for="transaction_date" class="form-label">Transaction Date</label>
            <input type="date" name="transaction_date" id="transaction_date" class="form-control" value="<?php echo date('Y-m-d', strtotime($transaction['transaction_date'])); ?>" required>
        </div>

        <!-- Submit button -->
        <button type="submit" class="btn btn-success">Update Transaction</button>
        <a href="gymManagement.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
