<?php
include 'dbh.php';
session_start();

// Ensure the transaction ID is provided
if (!isset($_POST['transaction_id'])) {
    header("Location: gymManagement.php");
    exit();
}

$transactionId = $_POST['transaction_id'];
echo "Received Transaction ID: " . $transactionId;

// Delete the transaction
$deleteQuery = "DELETE FROM transactions WHERE id = ?";
$stmt = $conn->prepare($deleteQuery);
$stmt->bind_param("i", $transactionId);

if ($stmt->execute()) {
    // Success message
    echo "<script>alert('Transaction deleted successfully!');</script>";
} else {
    // Error message
    echo "<script>alert('Failed to delete transaction. Please try again.');</script>";
}

$stmt->close();

// Redirect back to the gym management page
header("Location: transactions.php");
exit();
?>
