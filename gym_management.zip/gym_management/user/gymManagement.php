<?php

include 'dbh.php';
session_start(); // Start the session


// Initialize variables
$members = [];
$classes = [];
$transactions = [];

// Fetch members
$memberResult = $conn->query("SELECT * FROM customers");
if ($memberResult) {
    while ($row = $memberResult->fetch_assoc()) {
        $members[] = $row;
    }
}

// Fetch classes
$classResult = $conn->query("SELECT * FROM classes");
if ($classResult) {
    while ($row = $classResult->fetch_assoc()) {
        $classes[] = $row;
    }
}

// Fetch transactions
$transactionResult = $conn->query("SELECT * FROM transactions");
if ($transactionResult) {
    while ($row = $transactionResult->fetch_assoc()) {
        $transactions[] = $row;
    }
}

// Handle form submissions (e.g., for member registration or class enrollment)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Example: Class Enrollment
    if (isset($_POST['enroll_class'])) {
        $classId = $_POST['class_id'];
        $memberId = $_SESSION['user_id']; // Assuming user ID is stored in session

        $stmt = $conn->prepare("INSERT INTO class_enrollments (class_id, member_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $classId, $memberId);
        $stmt->execute();
        $stmt->close();
        header("Location: classes.php"); // Redirect after enrollment
        exit();
    }

}


?>

<?php
$enrolledClassesQuery = "SELECT classes.id, classes.instructor_name, classes.description, classes.schedule, class_enrollments.id AS enrollment_id
                         FROM classes
                         JOIN class_enrollments ON classes.id = class_enrollments.class_id
                         WHERE class_enrollments.member_id = ?";
$stmt = $conn->prepare($enrolledClassesQuery);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$enrolledClassesResult = $stmt->get_result();
?>

<?php
// Handle the deletion of an enrollment
if (isset($_POST['delete_enrollment'])) {
    $enrollmentId = $_POST['enrollment_id'];

    // Delete the specific enrollment from the database using the enrollment ID
    $deleteStmt = $conn->prepare("DELETE FROM class_enrollments WHERE id = ?");
    $deleteStmt->bind_param("i", $enrollmentId);
    if ($deleteStmt->execute()) {
        echo "<script>alert('Enrollment deleted successfully.');</script>";
    } else {
        echo "<script>alert('Error occurred during deletion.');</script>";
    }
    $deleteStmt->close();

    // Refresh the page after deletion to update the table
    header("Location: gymManagement.php");
    exit();
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym Management</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        /* Sidebar styles */
        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 20px;
        }

        .sidebar a {
            padding: 15px;
            text-align: center;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
        }

        .sidebar a:hover {
            background-color: #575d63;
        }

        .sidebar .active {
            background-color: #007bff;
        }

        /* Main content styles */
        .main-content {
            margin-left: 250px; /* Same width as the sidebar */
            padding: 20px;
        }

        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .top-bar {
            margin-left: 970px;
        }
        .profile-info {
            float: right;
            margin-right: 15px;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <?php include 'sidebar.php'; ?>
    </div>

    <!-- Main Content -->
    <div class="main-content">

        <div class="top-bar">
            <form action="../pages/home.php" method="POST" class="d-inline">
                <button type="submit" name="logout" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</button>
            </form>
        </div>

        <!-- User Details Table -->
        <div class="card mt-4">
            <div class="card-body">
                <h5 class="card-title">User Details</h5>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Member ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (isset($_SESSION['user_id'])) {
                            $userId = $_SESSION['user_id'];
                            $userResult = $conn->query("SELECT id, name, email FROM customers WHERE id = $userId");
                            if ($userResult) {
                                $user = $userResult->fetch_assoc();
                                echo "<tr>
                                        <td>{$user['name']}</td>
                                        <td>{$user['email']}</td>
                                        <td>{$user['id']}</td>
                                    </tr>";
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Classes Table -->
        <div class="card mt-4">
    <div class="card-body">
        <h5 class="card-title">Your Enrolled Classes</h5>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Class ID</th>
                    <th>Class Name</th>
                    <th>Description</th>
                    <th>Schedule</th>
                    <th>Actions</th> <!-- Action column for Edit/Delete -->
                </tr>
            </thead>
            <tbody>
    <?php while ($class = $enrolledClassesResult->fetch_assoc()): ?>
        <tr>
            <td><?php echo $class['id']; ?></td>
            <td><?php echo $class['instructor_name']; ?></td>
            <td><?php echo $class['description']; ?></td>
            <td><?php echo $class['schedule']; ?></td>
            <td>
                <!-- Delete button -->
                <form action="gymManagement.php" method="POST" class="d-inline">
                    <input type="hidden" name="enrollment_id" value="<?php echo $class['enrollment_id']; ?>">
                    <button type="submit" name="delete_enrollment" class="btn btn-danger btn-sm">Delete</button>
                </form>

                <!-- Edit button -->
                <form action="editEnrollment.php" method="POST" class="d-inline">
                    <input type="hidden" name="enrollment_id" value="<?php echo $class['enrollment_id']; ?>">
                    <button type="submit" name="edit_enrollment" class="btn btn-primary btn-sm">Edit</button>
                </form>
            </td>
        </tr>
    <?php endwhile; ?>
</tbody>

        </table>
    </div>
</div>

        <!-- Transaction History Table -->
        <div class="card mt-4">
            <div class="card-body">
                <h5 class="card-title">Transaction History</h5>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Transaction ID</th>
                            <th>Amount</th>
                            <th>Transaction Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $transactionQuery = "SELECT * FROM transactions WHERE member_id = ?";
                        $stmt = $conn->prepare($transactionQuery);
                        $stmt->bind_param("i", $_SESSION['user_id']);
                        $stmt->execute();
                        $transactionResult = $stmt->get_result();

                        while ($transaction = $transactionResult->fetch_assoc()) {
                            echo "<tr>
                                    <td>{$transaction['id']}</td>
                                    <td>{$transaction['amount']}</td>
                                    <td>{$transaction['transaction_date']}</td>
                                    <td>{$transaction['status']}</td>
                                  </tr>";
                        }
                        $stmt->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
