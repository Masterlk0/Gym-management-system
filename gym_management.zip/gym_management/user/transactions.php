<?php

include 'dbh.php';
session_start(); // Start the session


// Initialize variables
$members = [];
$classes = [];
$transactions = [];

// Fetch members
$memberResult = $conn->query("SELECT * FROM customers");
if ($memberResult) {
    while ($row = $memberResult->fetch_assoc()) {
        $members[] = $row;
    }
}

// Fetch classes
$classResult = $conn->query("SELECT * FROM classes");
if ($classResult) {
    while ($row = $classResult->fetch_assoc()) {
        $classes[] = $row;
    }
}

// Fetch transactions
$transactionResult = $conn->query("SELECT * FROM transactions");
if ($transactionResult) {
    while ($row = $transactionResult->fetch_assoc()) {
        $transactions[] = $row;
    }
}

// Handle form submissions (e.g., for member registration or class enrollment)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Example: Payment Processing
    if (isset($_POST['process_payment'])) {
        $amount = $_POST['amount'];
        $memberId = $_SESSION['user_id'];

        $stmt = $conn->prepare("INSERT INTO transactions (member_id, amount, transaction_date, transaction_type, status) VALUES (?, ?, NOW(), 'membership', 'completed')");
        $stmt->bind_param("id", $memberId, $amount);
        $stmt->execute();
        $stmt->close();
        header("Location: transactions.php"); // Redirect after payment
        exit();
    }
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym Management</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        /* Sidebar styles */
        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 20px;
        }

        .sidebar a {
            padding: 15px;
            text-align: center;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
        }

        .sidebar a:hover {
            background-color: #575d63;
        }

        .sidebar .active {
            background-color: #007bff;
        }

        /* Main content styles */
        .main-content {
            margin-left: 250px; /* Same width as the sidebar */
            padding: 20px;
        }

        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .top-bar{
            margin-left:970px;
        }
        .profile-info {
            float: right;
            margin-right: 15px;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->

    
    <div class="sidebar">
    <?php include 'sidebar.php'; ?>
    </div>

    <!-- Main Content -->
    <div class="main-content">


    <div class="top-bar">
        <form action="../pages/home.php" method="POST" class="d-inline">
            <button type="submit" name="logout" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </div>


        <!-- Row 2: Payment Processing and Transactions -->
        <div class="row">
            <!-- Payment Processing -->
            <div class="col-lg-6">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-money-check-alt"></i> Process Payment</h5>
                        <form action="transactions.php" method="POST">
                            <div class="mb-3">
                                <label for="amount" class="form-label">Amount</label>
                                <input type="number" class="form-control" id="amount" name="amount" required>
                            </div>
                            <button type="submit" name="process_payment" class="btn btn-primary w-100">Pay Now</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Transaction History -->
            <div class="col-lg-6">
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title"><i class="fas fa-receipt"></i> Transaction History</h5>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th> <!-- Added Actions column -->
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transactions as $transaction): ?>
                        <tr>
                            <td><?php echo $transaction['amount']; ?></td>
                            <td><?php echo $transaction['status']; ?></td>
                            <td><?php echo $transaction['transaction_date']; ?></td>
                            <td>
                                <!-- Edit button -->
                                <form action="editTransaction.php" method="POST" class="d-inline">
                                    <input type="hidden" name="transaction_id" value="<?php echo $transaction['id']; ?>">
                                    <button type="submit" class="btn btn-primary btn-sm">Edit</button>
                                </form>

                                <!-- Delete button -->
                                <form action="deleteTransaction.php" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this transaction?');">
                                    <input type="hidden" name="transaction_id" value="<?php echo $transaction['id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


                                    
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
