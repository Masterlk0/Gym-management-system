<?php
include 'dbh.php';
session_start();

if (!isset($_POST['edit_enrollment']) || !isset($_POST['enrollment_id'])) {
    header("Location: gymManagement.php");
    exit();
}

$enrollmentId = $_POST['enrollment_id'];

// Fetch current enrollment details
$enrollmentQuery = "SELECT * FROM class_enrollments WHERE id = ?";
$stmt = $conn->prepare($enrollmentQuery);
$stmt->bind_param("i", $enrollmentId);
$stmt->execute();
$enrollmentResult = $stmt->get_result();
$enrollment = $enrollmentResult->fetch_assoc();

// Fetch all available classes for selection
$classesQuery = "SELECT * FROM classes";
$classesResult = $conn->query($classesQuery);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Enrollment</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h3>Edit Enrollment</h3>
    <form action="updateEnrollment.php" method="POST">
        <input type="hidden" name="enrollment_id" value="<?php echo $enrollment['id']; ?>">

        <div class="mb-3">
            <label for="class_id" class="form-label">Select New Class</label>
            <select name="class_id" id="class_id" class="form-control">
                <?php while ($class = $classesResult->fetch_assoc()): ?>
                    <option value="<?php echo $class['id']; ?>" <?php if ($class['id'] == $enrollment['class_id']) echo 'selected'; ?>>
                        <?php echo $class['instructor_name'] . " - " . $class['schedule']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <button type="submit" name="update_enrollment" class="btn btn-success">Update Enrollment</button>
        <a href="gymManagement.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
