<?php
include 'dbh.php';
session_start();

// Ensure the form is submitted and enrollment ID is set
if (!isset($_POST['update_enrollment']) || !isset($_POST['enrollment_id']) || !isset($_POST['class_id'])) {
    header("Location: gymManagement.php");
    exit();
}

$enrollmentId = $_POST['enrollment_id'];
$newClassId = $_POST['class_id'];

// Update the class enrollment with the new class ID
$updateQuery = "UPDATE class_enrollments SET class_id = ? WHERE id = ?";
$stmt = $conn->prepare($updateQuery);
$stmt->bind_param("ii", $newClassId, $enrollmentId);

if ($stmt->execute()) {
    // Success message
    echo "<script>alert('Enrollment updated successfully!');</script>";
} else {
    // Error message
    echo "<script>alert('Failed to update enrollment. Please try again.');</script>";
}

$stmt->close();

// Redirect back to the gym management page after update
header("Location: gymManagement.php");
exit();
?>
