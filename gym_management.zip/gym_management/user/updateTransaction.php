<?php
include 'dbh.php';
session_start();

// Ensure required fields are provided
if (!isset($_POST['transaction_id'], $_POST['amount'], $_POST['status'], $_POST['transaction_date'])) {
    header("Location: gymManagement.php");
    exit();
}

$transactionId = $_POST['transaction_id'];
$amount = $_POST['amount'];
$status = $_POST['status'];
$transactionDate = $_POST['transaction_date'];

// Update the transaction in the database
$updateQuery = "UPDATE transactions SET amount = ?, status = ?, transaction_date = ? WHERE id = ?";
$stmt = $conn->prepare($updateQuery);
$stmt->bind_param("dssi", $amount, $status, $transactionDate, $transactionId);

if ($stmt->execute()) {
    // Success message
    echo "<script>alert('Transaction updated successfully!');</script>";
} else {
    // Error message
    echo "<script>alert('Failed to update transaction. Please try again.');</script>";
}

$stmt->close();

// Redirect back to the gym management page
header("Location: transactions.php");
exit();
?>
